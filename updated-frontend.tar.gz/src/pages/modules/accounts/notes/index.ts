export { NotesTab } from './NotesTab';
export type { NotesTabProps } from './NotesTab.types';
