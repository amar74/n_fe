export { default as FinancePage } from './FinancePage';
