export { default as ProposalsPage } from './ProposalsPage';
