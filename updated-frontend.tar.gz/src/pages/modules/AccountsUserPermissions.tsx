import UserPermissionsSection from '@/components/UserPermissionsSection';

export default function AccountsUserPermissionsPage() {
  return <UserPermissionsSection />;
}
