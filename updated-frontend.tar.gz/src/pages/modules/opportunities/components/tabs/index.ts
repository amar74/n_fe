export { default as OverviewTab } from './OverviewTab';
export { default as ClientStakeholderTab } from './ClientStakeholderTab';
export { default as CompetitionStrategyTab } from './CompetitionStrategyTab';
export { default as DeliveryModelTab } from './DeliveryModelTab';
export { default as TeamReferencesTab } from './TeamReferencesTab';
export { default as FinancialSummaryTab } from './FinancialSummaryTab';
export { default as LegalRisksTab } from './LegalRisksTab';