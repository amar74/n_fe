export { default as OpportunitiesDashboardPage } from './OpportunitiesDashboardPage';
export { default as AIAnalysisPage } from './AIAnalysisPage';
export { default as PipelineManagementPage } from './PipelineManagementPage';
