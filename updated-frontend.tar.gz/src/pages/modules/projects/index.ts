export { default as ProjectsPage } from './ProjectsPage';
