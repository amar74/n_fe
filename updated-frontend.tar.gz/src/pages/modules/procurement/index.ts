export { default as ProcurementPage } from './ProcurementPage';
