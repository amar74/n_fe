export { default as ResourcesPage } from './ResourcesPage';
