export { default as KpisPage } from './KpisPage';
