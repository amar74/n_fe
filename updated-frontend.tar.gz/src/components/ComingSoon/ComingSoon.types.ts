export type ComingSoonProps = {
  moduleId: string;
  moduleName: string;
}
