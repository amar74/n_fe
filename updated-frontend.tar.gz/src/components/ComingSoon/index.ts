export { default as ComingSoon } from './ComingSoon';
export type { ComingSoonProps } from './ComingSoon.types';
